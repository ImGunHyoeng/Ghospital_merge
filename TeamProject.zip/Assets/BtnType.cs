using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class BtnType : MonoBehaviour,IPointerEnterHandler,IPointerExitHandler
{
    public BTNType currentType;
    public Transform buttonScale;
    Vector3 defaultScale;
    bool isSound;
    public CanvasGroup MenuIn;
    public CanvasGroup MenuQuit;

    public void OnBthClick()
    {
        switch (currentType)
        {
            case BTNType.New:
                SceneLoader.LoadSceneHandle("Play", 0);
                break;

            case BTNType.Countinue:
                SceneLoader.LoadSceneHandle("Play", 1);
                break;

            case BTNType.Option:
                CanvasGroupOn(MenuIn);
                CanvasGroupOff(MenuQuit);
                break;

            case BTNType.Sound:
                if(isSound)
                {
                    Debug.Log("����OFF");
                }
                else
                {
                    Debug.Log("����ON");
                }
                isSound = !isSound;
                break;

            case BTNType.Quit:
                Application.Quit();
                Debug.Log("������");
                break;

            case BTNType.Back:
                CanvasGroupOn(MenuIn);
                CanvasGroupOff(MenuQuit);
                break;

            case BTNType.Phone:
                CanvasGroupOn(MenuIn);
                CanvasGroupOff(MenuQuit);
                break;

            case BTNType.Map:
                Debug.Log("���� ǥ��");
                break;
        }
    }

    public void CanvasGroupOn(CanvasGroup cg)
    {
        cg.alpha = 1;
        cg.interactable = true;
        cg.blocksRaycasts = true;
    }
    public void CanvasGroupOff(CanvasGroup cg)
    {
        cg.alpha = 0;
        cg.interactable = false;
        cg.blocksRaycasts = false;
    }

    void Start()
    {
        defaultScale = buttonScale.localScale;
    }


    public void OnPointerEnter(PointerEventData eventData)
    {
        buttonScale.localScale = defaultScale * 1.2f;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        buttonScale.localScale = defaultScale;
    }
}
